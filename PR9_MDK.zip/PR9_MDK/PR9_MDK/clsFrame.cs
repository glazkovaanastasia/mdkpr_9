﻿using PR9_MDK.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR9_MDK
{
    class clsFrame
    {
        public static Frame frmObject;
    }

    public class Frame
    {
        public static implicit operator Frame(System.Windows.Controls.Frame v)
        {
            throw new NotImplementedException();
        }

        internal void Navigate(PageFor pageFor)
        {
            throw new NotImplementedException();
        }

        internal void Navigate(PageWhile pageWhile)
        {
            throw new NotImplementedException();
        }

        internal void Navigate(PageDoWhile pageDoWhile)
        {
            throw new NotImplementedException();
        }
    }
}
